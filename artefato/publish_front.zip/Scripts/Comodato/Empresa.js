﻿jQuery(document).ready(function () {
    $('#EN_CEP').mask('00000-000');
    $('#NR_CNPJ').mask('00.000.000/0000-00');
    //$('#TX_Telefone').mask('00 00000-0000');
    //$('#TX_Fax').mask('00 00000-0000');
});