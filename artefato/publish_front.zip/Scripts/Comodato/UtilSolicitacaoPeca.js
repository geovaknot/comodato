﻿var statusItemNovoRascunho = 1;
var statusItemPendente = 2;
var statusItemAprovado = 3;
var statusItemCancelado = 4;
var statusItemRecebido = 5;
var statusItemSolicitado = 6;
var statusItemRecebidoPendencia = 7;