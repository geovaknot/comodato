﻿jQuery(document).ready(function () {
    $('#VL_EXPECTATIVA_PADRAO').maskMoney({ allowNegative: true, thousands: '.', decimal: ',', allowZero: true });
});