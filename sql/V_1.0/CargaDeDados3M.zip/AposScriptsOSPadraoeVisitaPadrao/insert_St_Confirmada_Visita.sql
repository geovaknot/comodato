insert into tbTpStatusVisitaPadrao (ST_STATUS_VISITA, DS_STATUS_VISITA, nidUsuarioAtualizacao, dtmDataHoraAtualizacao)
values(6, 'Confirmada', 1, '2021-09-02 16:16:08.627')