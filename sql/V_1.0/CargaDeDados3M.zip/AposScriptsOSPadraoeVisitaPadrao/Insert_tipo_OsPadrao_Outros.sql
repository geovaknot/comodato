insert into tbTpOSPadrao (CD_TIPO_OS, DS_TIPO_OS, nidUsuarioAtualizacao, dtmDataHoraAtualizacao)
			values (4, 'Outros', 1, GETDATE())