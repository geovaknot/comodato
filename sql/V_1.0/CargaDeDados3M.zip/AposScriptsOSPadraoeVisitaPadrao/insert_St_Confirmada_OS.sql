insert into tbTpStatusOsPadrao (ST_STATUS_OS, DS_STATUS_OS, nidUsuarioAtualizacao, dtmDataHoraAtualizacao)
values(5, 'Confirmada', 1, '2021-09-02 16:16:08.627')