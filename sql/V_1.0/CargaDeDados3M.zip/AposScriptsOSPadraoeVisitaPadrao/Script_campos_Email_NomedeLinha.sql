ALTER TABLE tbOSPadrao ADD NOME_LINHA varchar(50) NULL
ALTER TABLE tbOSPadrao ADD Email varchar(50) NULL
ALTER TABLE tbVisitaPadrao ADD Email varchar(50) NULL