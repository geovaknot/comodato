
insert into tbTpMotivoVisitaPadrao (CD_MOTIVO_VISITA, DS_MOTIVO_VISITA, nidUsuarioAtualizacao, dtmDataHoraAtualizacao)
values (4, 'Carga de dados', 1, GETDATE())