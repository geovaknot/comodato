insert into tbFuncao(ccdFuncao, cdsFuncao, bidAtivo, nidUsuarioAtualizacao, dtmDataHoraAtualizacao) 
			values('menuPecas', 'Ralat�rio de Pe�as', 1, 1, GETDATE())

insert into tbFuncao(ccdFuncao, cdsFuncao, bidAtivo, nidUsuarioAtualizacao, dtmDataHoraAtualizacao) 
			values('KatTecnicoVisita', 'Menu Relat�rios -> Kat por T�cnico Visita', 1, 1, GETDATE())