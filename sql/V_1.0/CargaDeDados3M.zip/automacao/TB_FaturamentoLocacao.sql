GO

/****** Object:  Table [dbo].[TB_FaturamentoLocacao]    Script Date: 11/11/2021 08:32:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TB_FaturamentoLocacao](
	[Codigo] [varchar](15) NULL,
	[Descricao] [nvarchar](50) NULL
) ON [PRIMARY]
GO


