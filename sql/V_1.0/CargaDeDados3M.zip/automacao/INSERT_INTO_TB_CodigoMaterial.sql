GO

INSERT INTO [dbo].[TB_CodigoMaterial] (CD_Material, CD_Descricao)
VALUES 
('HB003001144', 'Servi�o Aluguel Maq Empacot'),
('HB003004320', 'Aluguel Armadora de caixa 3M'),
('HB003003652', 'Loca��o Lixaderia Rebar e Acab'),
('HB003003520', 'Kit E-A=RFIT Aluguel'),
('HB003003926', 'Servi�o Aluguel p/Identific'),
('HB003005145', 'Aluguel Ferremen Produ��o Tar'),
('HB003004148', 'Aluguel Espa�o Fisico C. SAFETY');
GO


