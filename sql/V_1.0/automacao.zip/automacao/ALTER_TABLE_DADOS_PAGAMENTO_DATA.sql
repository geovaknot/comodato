GO

/****** Object:  Table [dbo].[TB_DadosPagamento]    Script Date: 19/11/2021 15:22:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER TABLE [dbo].[TB_DadosPagamento]
ADD DataEmissaoNF datetime
GO
