GO

/****** Object:  Table [dbo].[TB_DadosFaturamento]    Script Date: 22/11/2021 15:26:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

ALTER TABLE [dbo].[TB_DadosFaturamento] ADD ID NUMERIC(6,0) IDENTITY(1,1)
GO


